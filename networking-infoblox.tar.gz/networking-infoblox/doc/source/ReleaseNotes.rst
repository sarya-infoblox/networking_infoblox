Release Notes
-------------

* Support for python3.8 version
* Support for Openstack stable/xena release
